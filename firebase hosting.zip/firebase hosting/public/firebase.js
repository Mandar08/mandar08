const firebaseConfig = {
    apiKey: "AIzaSyCpCA-fuZhMsK7AEdyEjVHSqoAaZadduOE",
    authDomain: "portfolio-a11b4.firebaseapp.com",
    databaseURL: "https://portfolio-a11b4.firebaseio.com",
    projectId: "portfolio-a11b4",
    storageBucket: "portfolio-a11b4.appspot.com",
    messagingSenderId: "330142436220",
    appId: "1:330142436220:web:bcb7b6fa4bc5b12b8db2f9",
    measurementId: "G-YRVNG64N76"
  };